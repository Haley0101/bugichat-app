class langJP {
  String titleText = "BUGI CHAT";

  String loginText = "ログイン";
  String unLoginText = "非会員として利用";
  String signUp = "会員登録";

  String idText = "ID";
  String idHintText = "IDを入力してください。";

  String pwText = "PW";
  String pwHintText = "PWを入力してください。";

  String chatBotInputBox = "BUGI CHATに尋ねる内容を入力してください!";
  String chatBotHintText = "BUGIに「釜山ワールドエキスポ」について質問する!!";

  String policyText1 = "利用規約";
  String policyText2 = "個人情報処理方針";
  String logoutText = "ログアウト";
  String deleteAccount = "会員脱退";

  String companyName = "大津電子通信高等学校 | ゲーム開発機能部";
  String companyName2 = "BD.GG | BUGI CHAT";
}