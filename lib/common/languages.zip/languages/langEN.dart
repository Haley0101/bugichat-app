class langEN {
  String titleText = "BUGI CHAT";

  String loginText = "Login";
  String unLoginText = "Use as a non-member";
  String signUp = "SignUp";

  String idText = "ID";
  String idHintText = "Please enter your ID.";

  String pwText = "PW";
  String pwHintText = "Please enter your password.";

  String chatBotInputBox = "Enter your question on BUGI CHAT!";
  String chatBotHintText = "Ask BUGI about 'Busan World Expo'!!";

  String policyText1 = "Terms of Use";
  String policyText2 = "privacy policy";
  String logoutText = "logout";
  String deleteAccount = "delete account";

  String companyName = "BusanDaejin | Game Development Department";
  String companyName2 = "BD.GG | BUGI CHAT";
}