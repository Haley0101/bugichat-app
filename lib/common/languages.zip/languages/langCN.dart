class langCN {
  String titleText = "BUGI CHAT";

  String loginText = "로登录";
  String unLoginText = "以非会员身份使用";
  String signUp = "加入会员";

  String idText = "ID";
  String idHintText = "请输入您的ID";

  String pwText = "PW";
  String pwHintText = "请输入PW";

  String chatBotInputBox = "输入您想在 BUGI CHAT 上提出的问题！";
  String chatBotHintText = "向 Boogiechat 询问“釜山世博会”！！";

  String policyText1 = "使用条款";
  String policyText2 = "隐私政策";
  String logoutText = "登出";
  String deleteAccount = "成员分裂国家";

  String companyName = "大真电子通信高中 | 游戏开发部";
  String companyName2 = "BD.GG | BUGI CHAT";
}