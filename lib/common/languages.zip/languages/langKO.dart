class langKO {
  String titleText = "부기챗";

  String loginText = "로그인";
  String unLoginText = "비회원으로 이용하기";
  String signUp = "회원가입";

  String idText = "아이디";
  String idHintText = "아이디를 입력해주세요.";

  String pwText = "비밀번호";
  String pwHintText = "비밀번호를 입력해주세요.";

  String chatBotInputBox = "부기챗에게 물어 볼 것을 입력해 주세요!";
  String chatBotHintText = "부기에게 부산월드엑스포에 대해 질문 해주세요!!";

  String policyText1 = "이용약관";
  String policyText2 = "개인정보처리방침";
  String logoutText = "로그아웃";
  String deleteAccount = "회원탈퇴";

  String companyName = "대진전자통신고등학교 | 기능부";
  String companyName2 = "BD.GG | 부기챗";
}